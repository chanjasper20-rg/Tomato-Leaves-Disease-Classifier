from pathlib import Path
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit

def find_tomato_class_dirs(base_dir: str):
    base = Path(base_dir)
    class_dirs = []
    for p in base.rglob("*"):
        if p.is_dir() and p.name.startswith("Tomato"):
            class_dirs.append(p)
    return sorted(class_dirs)

def build_df(base_dir: str) -> pd.DataFrame:
    rows = []
    for cdir in find_tomato_class_dirs(base_dir):
        label = cdir.name
        for img in cdir.glob("*"):
            if img.suffix.lower() in {".jpg",".jpeg",".png",".bmp"}:
                rows.append({"path": str(img), "label": label})
    return pd.DataFrame(rows)

def stratified_80_10_10(df: pd.DataFrame, seed: int = 42):
    assert "label" in df.columns, "DataFrame must have a 'label' column."
    sss1 = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=seed)
    i_train, i_temp = next(sss1.split(df, df["label"]))
    train_df = df.iloc[i_train].reset_index(drop=True)
    temp_df  = df.iloc[i_temp].reset_index(drop=True)

    sss2 = StratifiedShuffleSplit(n_splits=1, test_size=0.5, random_state=seed)
    i_val, i_test = next(sss2.split(temp_df, temp_df["label"]))
    val_df  = temp_df.iloc[i_val].reset_index(drop=True)
    test_df = temp_df.iloc[i_test].reset_index(drop=True)

    return train_df, val_df, test_df

def describe_splits(train_df: pd.DataFrame, val_df: pd.DataFrame, test_df: pd.DataFrame) -> str:
    parts = []
    parts.append(f"Train/Val/Test sizes: {len(train_df)} / {len(val_df)} / {len(test_df)}")
    from collections import Counter
    parts.append(f"Train distribution: {Counter(train_df['label'])}")
    parts.append(f"Val distribution:   {Counter(val_df['label'])}")
    parts.append(f"Test distribution:  {Counter(test_df['label'])}")
    return "\n".join(parts)