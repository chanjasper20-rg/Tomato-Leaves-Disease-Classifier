#!/usr/bin/env python3
"""
Evaluate classification checkpoints on an ImageFolder dataset, optionally with
Stratified K-fold cross-validation. For each fold, we evaluate all checkpoints
on the validation split and save per-model reports. A final summary aggregates
metrics across folds (mean ± std) per model.

NEW:
- --reorder-cols to reorder model output columns (true_idx -> pred_idx) so a
  PV-trained head can be evaluated on a Combined dataset label order.
- --auto-permute to auto-detect per-checkpoint class-order permutation via the
  Hungarian algorithm (confusion-matrix based) and reorder logits accordingly.
"""
import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms, models

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    roc_auc_score,
    average_precision_score,
)
from sklearn.model_selection import StratifiedKFold
import pandas as pd
from scipy.optimize import linear_sum_assignment

try:
    import matplotlib.pyplot as plt
    MATPLOTLIB_OK = True
except Exception:
    MATPLOTLIB_OK = False

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]

# --------- helpers for arch guessing & state_dict cleanup ----------
import subprocess
import sys

def run_calibration(npz_path: Path, outdir: Path):
    script = Path("src/calibration_metrics.py")
    if not script.exists():
        print(f"[WARN] {script} not found; skipping calibration for {npz_path.parent.name}")
        return
    outdir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable, str(script),
        "--npz", str(npz_path),
        "--bins", "15",
        "--binning", "uniform",
        "--outdir", str(outdir),
    ]
    try:
        print(f"[INFO] Running calibration → {outdir} ...")
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        print(f"[WARN] Calibration failed for {npz_path}: {e}")

def guess_arch_from_name(name: str) -> Optional[str]:
    n = name.lower()
    mapping = {
        "resnet18": "resnet18",
        "resnet50": "resnet50",
        "densenet121": "densenet121",
        "mobilenet_v2": "mobilenet_v2",
        "mobilenetv2": "mobilenet_v2",
        "efficientnet_b0": "efficientnet_b0",
        "efficientnetb0": "efficientnet_b0",
    }
    for key, arch in mapping.items():
        if key in n:
            return arch
    return None

def strip_prefix_once(k: str, prefix: str) -> str:
    return k[len(prefix):] if k.startswith(prefix) else k

def normalize_state_dict(state_dict: dict, variant: str) -> dict:
    prefixes = []
    if variant == "raw":
        prefixes = []
    elif variant == "no_module":
        prefixes = ["module."]
    elif variant == "no_model":
        prefixes = ["model."]
    elif variant == "no_backbone":
        prefixes = ["backbone."]
    elif variant == "no_net":
        prefixes = ["net."]
    elif variant == "no_model_module":
        prefixes = ["model.", "module."]
    elif variant == "deep_strip":
        prefixes = ["model.", "module.", "backbone.", "net.", "encoder."]

    cleaned = {}
    for k, v in state_dict.items():
        newk = k
        for p in prefixes:
            newk = strip_prefix_once(newk, p)
        cleaned[newk] = v
    return cleaned

def try_load_state_dict(model: nn.Module, sd: dict, *, strict=False):
    model_sd = model.state_dict()
    pruned = {}
    dropped = []

    for k, v in sd.items():
        if k in model_sd:
            if tuple(model_sd[k].shape) == tuple(v.shape):
                pruned[k] = v
            else:
                dropped.append(k)

    if dropped:
        print(f"[INFO] Dropping {len(dropped)} mismatched keys (e.g., classifier/fc)")

    res = model.load_state_dict(pruned, strict=strict)
    if isinstance(res, tuple) and len(res) == 2:
        missing, unexpected = res
    else:
        missing = getattr(res, "missing_keys", [])
        unexpected = getattr(res, "unexpected_keys", [])
    unexpected = list(unexpected) + dropped
    return missing, unexpected

def score_mismatch(missing, unexpected) -> int:
    return len(missing) + len(unexpected)

# ------------------- device and model builders --------------------

def get_device(device_arg: str) -> torch.device:
    if device_arg == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    return torch.device(device_arg)

def build_model(arch: str, num_classes: int) -> nn.Module:
    if not hasattr(models, arch):
        raise ValueError(f"Unknown architecture '{arch}'. Must be a torchvision.models name.")
    model_fn = getattr(models, arch)
    try:
        model = model_fn(weights=None)
    except TypeError:
        model = model_fn(pretrained=False)

    if hasattr(model, "fc") and isinstance(model.fc, nn.Linear):
        in_features = model.fc.in_features
        model.fc = nn.Linear(in_features, num_classes)
    elif hasattr(model, "classifier"):
        if isinstance(model.classifier, nn.Linear):
            in_features = model.classifier.in_features
            model.classifier = nn.Linear(in_features, num_classes)
        elif isinstance(model.classifier, nn.Sequential):
            seq = list(model.classifier)
            for i in reversed(range(len(seq))):
                if isinstance(seq[i], nn.Linear):
                    in_features = seq[i].in_features
                    seq[i] = nn.Linear(in_features, num_classes)
                    break
            model.classifier = nn.Sequential(*seq)
        else:
            raise ValueError("Unsupported classifier structure; please edit the script to handle your model.")
    else:
        replaced = False
        for attr in ["head", "heads", "last_linear"]:
            if hasattr(model, attr):
                mod = getattr(model, attr)
                if isinstance(mod, nn.Linear):
                    in_features = mod.in_features
                    setattr(model, attr, nn.Linear(in_features, num_classes))
                    replaced = True
                    break
        if not replaced:
            raise ValueError("Couldn't find a classifier head to replace; specify a different --arch or modify this script.")
    return model

# -------------------- robust checkpoint loader --------------------

def _safe_torch_load(path: Path):
    # Support PyTorch versions without the 'weights_only' kwarg.
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")

def load_checkpoint_as_model(
    ckpt_path: Path,
    arch: Optional[str],
    num_classes: int,
    device: torch.device,
    arch_map: Optional[dict] = None,
) -> nn.Module:
    obj = _safe_torch_load(ckpt_path)

    if isinstance(obj, nn.Module):
        model = obj.to(device)
        model.eval()
        return model

    if isinstance(obj, dict):
        candidates = []
        if "state_dict" in obj and isinstance(obj["state_dict"], dict):
            candidates.append(("state_dict", obj["state_dict"]))
        for k in ["model_state_dict", "model", "network", "net", "backbone"]:
            if k in obj and isinstance(obj[k], dict):
                candidates.append((k, obj[k]))
        if not candidates:
            candidates.append(("root", obj))

        stem = ckpt_path.stem.lower()
        arch_from_map = None
        if arch_map:
            arch_from_map = arch_map.get(stem) or arch_map.get(ckpt_path.name) or arch_map.get(str(ckpt_path))
        chosen_arch = arch or arch_from_map or guess_arch_from_name(stem)

        def build_torchvision(a: str) -> nn.Module:
            return build_model(a, num_classes)

        def build_timm(a: str) -> Optional[nn.Module]:
            try:
                import timm
            except Exception:
                return None
            return timm.create_model(a, pretrained=False, num_classes=num_classes)

        arch_pairs: List[Tuple[str, str]] = []
        if chosen_arch:
            arch_pairs.append(("torchvision", chosen_arch))
            timm_alias_map = {
                "mobilenet_v2": "mobilenetv2_100",
                "efficientnet_b0": "efficientnet_b0",
                "resnet18": "resnet18",
                "resnet50": "resnet50",
                "densenet121": "densenet121",
            }
            timm_name = timm_alias_map.get(chosen_arch)
            if timm_name:
                arch_pairs.append(("timm", timm_name))

        best_choice = None
        for tag, sd in candidates:
            for variant in ["raw", "no_module", "no_model", "no_backbone", "no_net", "no_model_module", "deep_strip"]:
                cleaned = normalize_state_dict(sd, variant)
                tried_any = False

                if arch_pairs:
                    for fw, a in arch_pairs:
                        model = None
                        if fw == "torchvision":
                            try:
                                model = build_torchvision(a)
                            except Exception:
                                model = None
                        else:
                            model = build_timm(a)
                        if model is None:
                            continue

                        tried_any = True
                        missing, unexpected = try_load_state_dict(model, cleaned, strict=False)
                        s = score_mismatch(missing, unexpected)
                        if (best_choice is None) or (s < best_choice[0]):
                            best_choice = (s, fw, a, variant, cleaned, model)
                            if s <= 4:
                                model.to(device).eval()
                                return model

                if not tried_any and chosen_arch is None:
                    raise ValueError(
                        f"Checkpoint '{ckpt_path.name}' contains a state_dict but no architecture could be resolved.\n"
                        f"Fixes:\n"
                        f"  • Pass --arch <arch_name> (e.g., --arch resnet50)\n"
                        f"  • OR provide --arch-map JSON mapping filename→arch\n"
                        f"  • OR rename file to include an arch token (e.g., '...resnet50...')\n"
                        f"  • If trained with timm, install timm and use its model name (mobilenetv2_100, efficientnet_b0)"
                    )

        if best_choice is not None:
            score, fw, a, variant, cleaned, model = best_choice
            if score > 50:
                print(
                    f"[WARN] Large key mismatch for {ckpt_path.name} (score={score}). "
                    f"Framework={fw}, arch={a}, cleanup={variant}. This checkpoint may not match."
                )
            model.to(device).eval()
            return model

        raise ValueError(
            f"Could not map checkpoint '{ckpt_path.name}' to a compatible model.\n"
            f"Tips:\n"
            f"  • Pass --arch explicitly (e.g., --arch resnet50)\n"
            f"  • Provide --arch-map JSON; or include arch in filename\n"
            f"  • If trained with timm, install timm and use its name (mobilenetv2_100, efficientnet_b0)"
        )

    raise ValueError(f"Unsupported checkpoint format for {ckpt_path.name}")

# ------------------- NEW: reorder-cols & auto-permute -------------

def parse_reorder_cols(spec: Optional[str]) -> Optional[List[int]]:
    """
    Accepts either:
      - a comma-separated list of ints, e.g. "0,1,9,2,8,7,3,4,5,6"
      - a path to a JSON file that contains a list[int]
    Returns the parsed list or None.
    """
    if not spec:
        return None
    spec = spec.strip()
    p = Path(spec)
    if p.exists():
        arr = json.loads(p.read_text())
        if not (isinstance(arr, list) and all(isinstance(i, int) for i in arr)):
            raise ValueError("--reorder-cols JSON must be a list of ints")
        return arr
    parts = [s.strip() for s in spec.split(",") if s.strip() != ""]
    try:
        return [int(s) for s in parts]
    except ValueError:
        raise ValueError("Invalid --reorder-cols list. Use comma-separated ints or a JSON file.")

def auto_permute_by_confusion(y_true: np.ndarray, probs_model: np.ndarray):
    """
    Given ground-truth indices (dataset order) and model probs in its native order,
    compute the best pred_idx->true_idx permutation and the corresponding
    true_idx->pred_idx ordering to reorder columns.
    Returns (perm_pred_to_true, cols_true_to_pred) as lists.
    """
    y_pred_raw = probs_model.argmax(axis=1)
    C = probs_model.shape[1]
    cm = confusion_matrix(y_true, y_pred_raw, labels=list(range(C)))
    r, c = linear_sum_assignment(-cm)       # maximize matches
    perm = np.zeros(C, dtype=int); perm[c] = r         # pred_idx -> true_idx
    cols = np.argsort(perm)                                # true_idx -> pred_idx
    return perm.tolist(), cols.tolist()

# ------------------- dataloading & evaluation ---------------------

def build_dataset(
    data_root: Path,
    img_size: int,
    center_crop: bool = True,
):
    tforms = []
    if center_crop:
        tforms.extend([
            transforms.Resize(int(img_size * 1.14)),
            transforms.CenterCrop(img_size),
        ])
    else:
        tforms.extend([
            transforms.Resize((img_size, img_size)),
        ])
    tforms.extend([
        transforms.ToTensor(),
        transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
    ])
    tfm = transforms.Compose(tforms)

    ds = datasets.ImageFolder(root=str(data_root), transform=tfm)
    class_names = ds.classes
    return ds, class_names

def make_loader(ds, batch_size: int, num_workers: int, indices: Optional[List[int]] = None) -> DataLoader:
    if indices is not None:
        ds = Subset(ds, indices)
    return DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=True)

@torch.no_grad()
def infer_all(model: nn.Module, loader: DataLoader, device: torch.device) -> Tuple[np.ndarray, np.ndarray]:
    logits_list = []
    y_list = []
    for images, targets in loader:
        images = images.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        outputs = model(images)
        if isinstance(outputs, (tuple, list)):
            outputs = outputs[0]
        logits = outputs.detach().float()
        if logits.ndim == 1:
            logits = logits.unsqueeze(0)
        logits_list.append(logits.cpu().numpy())
        y_list.append(targets.cpu().numpy())
    all_logits = np.concatenate(logits_list, axis=0)
    all_targets = np.concatenate(y_list, axis=0)
    return all_logits, all_targets


def topk_accuracy(y_true: np.ndarray, probs: np.ndarray, ks: List[int]) -> Dict[int, float]:
    preds_sorted = np.argsort(-probs, axis=1)
    metrics = {}
    for k in ks:
        correct = (preds_sorted[:, :k] == y_true[:, None]).any(axis=1)
        metrics[k] = float(np.mean(correct))
    return metrics


def compute_metrics_from_probs(
    y_true: np.ndarray,
    probs: np.ndarray,
    class_names: List[str],
    ks: List[int],
) -> Tuple[Dict, pd.DataFrame]:
    y_pred = probs.argmax(axis=1)

    overall_acc = accuracy_score(y_true, y_pred)
    topk = topk_accuracy(y_true, probs, ks)

    report = classification_report(
        y_true, y_pred, target_names=class_names, output_dict=True, zero_division=0
    )
    per_class_df = pd.DataFrame(report).transpose()

    macro_f1 = f1_score(y_true, y_pred, average="macro")

    try:
        roc_auc_macro_ovr = roc_auc_score(y_true, probs, multi_class="ovr", average="macro")
    except Exception:
        roc_auc_macro_ovr = float("nan")

    try:
        from sklearn.preprocessing import label_binarize
        y_true_bin = label_binarize(y_true, classes=np.arange(len(class_names)))
        pr_auc_macro = average_precision_score(y_true_bin, probs, average="macro")
        per_class_ap = average_precision_score(y_true_bin, probs, average=None)
    except Exception:
        pr_auc_macro = float("nan")
        per_class_ap = [float("nan")] * len(class_names)

    summary = {
        "accuracy": overall_acc,
        "topk": topk,
        "macro_f1": macro_f1,
        "roc_auc_macro_ovr": roc_auc_macro_ovr,
        "pr_auc_macro": pr_auc_macro,
        "per_class_ap": {cls: float(ap) for cls, ap in zip(class_names, per_class_ap)},
    }

    return summary, per_class_df


def save_confusion_matrix(y_true: np.ndarray, y_pred: np.ndarray, class_names: List[str], outpath: Path):
    if not MATPLOTLIB_OK:
        return
    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(class_names))))
    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(111)
    im = ax.imshow(cm, interpolation="nearest")
    ax.set_title("Confusion Matrix")
    plt.colorbar(im)
    tick_marks = np.arange(len(class_names))
    ax.set_xticks(tick_marks)
    ax.set_xticklabels(class_names, rotation=90)
    ax.set_yticks(tick_marks)
    ax.set_yticklabels(class_names)
    plt.tight_layout()
    plt.xlabel("Predicted label")
    plt.ylabel("True label")
    fig.savefig(outpath, bbox_inches="tight", dpi=160)
    plt.close(fig)


def evaluate_checkpoint(ckpt_path: Path, args, device, loader, class_names, fold_idx: Optional[int] = None):
    dataset_num_classes = len(class_names)
    model = load_checkpoint_as_model(
        ckpt_path,
        getattr(args, "arch", None),
        dataset_num_classes,
        device,
        arch_map=getattr(args, "arch_map_dict", None),
    )

    logits, y_true = infer_all(model, loader, device)

    # Softmax in the MODEL's native class order
    probs_model = torch.softmax(torch.from_numpy(logits), dim=1).numpy()

    applied_cols = None
    applied_perm = None

    # 1) If user provides explicit mapping, use it
    if getattr(args, "reorder_cols", None):
        cols = args.reorder_cols
        if len(cols) != probs_model.shape[1]:
            raise ValueError(f"--reorder-cols length {len(cols)} != model outputs dim {probs_model.shape[1]}")
        probs_model = probs_model[:, cols]
        applied_cols = cols
    # 2) Otherwise, auto-permute if requested
    elif getattr(args, "auto_permute", False):
        perm, cols = auto_permute_by_confusion(y_true, probs_model)  # lists
        probs_model = probs_model[:, cols]
        applied_perm = perm
        applied_cols = cols

    probs = probs_model
    if probs.shape[1] != dataset_num_classes:
        raise ValueError(f"Model outputs {probs.shape[1]} columns but dataset has {dataset_num_classes} classes. "
                         f"Consider using --reorder-cols or --auto-permute.")

    y_pred = probs.argmax(axis=1)

    summary, per_class_df = compute_metrics_from_probs(y_true, probs, class_names, args.topk)

    rel = ckpt_path.resolve().relative_to(Path(args.checkpoints_dir).resolve())
    model_id = str(rel).replace("\\", "/")
    safe_id = model_id.replace("/", "__")

    fold_dir = Path(args.outdir)
    if fold_idx is not None:
        fold_dir = fold_dir / f"fold_{fold_idx}"
    per_model_dir = fold_dir / safe_id
    per_model_dir.mkdir(parents=True, exist_ok=True)

    per_class_df.to_csv(per_model_dir / "per_class_report.csv", index=True)
    save_confusion_matrix(y_true, y_pred, class_names, per_model_dir / "confusion_matrix.png")
    with open(per_model_dir / "detail.json", "w") as f:
        detail = {
            **summary,
            "applied_reorder_cols": applied_cols,
            "discovered_perm_pred_to_true": applied_perm,
        }
        json.dump(detail, f, indent=2)

    npz_path = per_model_dir / "probs_and_labels.npz"
    np.savez(npz_path, probs=probs, y_true=y_true)

    df_probs = pd.DataFrame(probs, columns=[f"prob_{i}" for i in range(dataset_num_classes)])
    df_probs.insert(0, "y_true", y_true)
    df_probs.insert(1, "y_pred", y_pred)
    df_probs.to_csv(per_model_dir / "predictions_with_probs.csv", index=False)

    with open(per_model_dir / "CALIBRATION_README.txt", "w") as f:
        f.write(
            "Run calibration like this:\n"
            f"python calibration_metrics.py --npz \"{npz_path}\" --bins 15 --binning uniform --outdir \"{per_model_dir / 'calibration'}\"\n"
            "Or using CSV:\n"
            f"python calibration_metrics.py --csv \"{per_model_dir / 'predictions_with_probs.csv'}\" --label-col y_true --prob-prefix prob_ --bins 15 --binning uniform --outdir \"{per_model_dir / 'calibration_csv'}\"\n"
        )

    if args.run_calibration:
        run_calibration(npz_path=npz_path, outdir=per_model_dir / "calibration")

    row = {
        "model": model_id,
        "accuracy": summary["accuracy"],
        **{f"top{k}": v for k, v in summary["topk"].items()},
        "macro_f1": summary["macro_f1"],
        "roc_auc_macro_ovr": summary["roc_auc_macro_ovr"],
        "pr_auc_macro": summary["pr_auc_macro"],
        "outdir": str(per_model_dir),
    }
    if fold_idx is not None:
        row["fold"] = int(fold_idx)
    return row


def find_checkpoints(checkpoints_dir: Path) -> List[Path]:
    exts = {".pt", ".pth", ".ckpt"}
    files = [p for p in sorted(checkpoints_dir.rglob("*")) if p.is_file() and p.suffix.lower() in exts]
    return files

# ----------------------------- CLI --------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate image classification models on an ImageFolder dataset (with optional K-fold CV).")
    parser.add_argument("--data-root", type=str, required=True, help="Path to dataset root (ImageFolder).")
    parser.add_argument("--checkpoints-dir", type=str, default="checkpoints", help="Directory containing model checkpoints.")
    parser.add_argument("--arch", type=str, default=None, help="Optional architecture override for state_dict checkpoints (e.g., resnet50). \n" "If omitted, the loader will try arch_map, then filename, then timm fallbacks.")
    parser.add_argument("--arch-map", type=str, default=None, help="Path to JSON mapping from checkpoint stem/filename to arch name.")
    parser.add_argument("--num-classes", type=int, default=None, help="(Deprecated) Dataset classes; autodetected from ImageFolder.")
    parser.add_argument("--reorder-cols", type=str, default=None, help=("Reorder columns of model outputs to match dataset label order. "
            "Either a comma-separated list like '0,1,9,2,8,7,3,4,5,6' or a path to a JSON file containing an int array. "
            "Length must equal the model's output dim."))
    parser.add_argument("--auto-permute", action="store_true", help="Auto-detect per-checkpoint label-order via Hungarian assignment and reorder logits accordingly.")
    parser.add_argument("--img-size", type=int, default=224, help="Input image size (shorter side/crop).")
    parser.add_argument("--batch-size", type=int, default=64, help="Batch size for evaluation.")
    parser.add_argument("--num-workers", type=int, default=4, help="Dataloader workers.")
    parser.add_argument("--no-center-crop", action="store_true", help="Disable resize+center-crop, use direct resize to img-size.")
    parser.add_argument("--device", type=str, default="auto", help="cuda, cpu, mps, or auto.")
    parser.add_argument("--topk", type=int, nargs="+", default=[1, 5], help="Top-k values to compute (e.g., --topk 1 3 5)."
    )
    parser.add_argument("--outdir", type=str, default="eval_reports", help="Output directory for reports.")
    parser.add_argument("--run-calibration", action="store_true", help="Also run calibration plots per fold/model (slower).")

    # Cross-validation options
    parser.add_argument("--cv-folds", type=int, default=1, help="Number of Stratified K-folds. 1 disables CV (single full-dataset eval)."
    )
    parser.add_argument("--cv-seed", type=int, default=42, help="Random seed for StratifiedKFold shuffling.")
    parser.add_argument("--cv-shuffle", action="store_true", help="Shuffle data before splitting (recommended)."
    )

    args = parser.parse_args()
    args.reorder_cols = parse_reorder_cols(args.reorder_cols)
    return args


def aggregate_and_save(all_rows: List[Dict], outdir: Path):
    df = pd.DataFrame(all_rows)

    # Order columns
    topk_cols = sorted({k for row in all_rows for k in row.keys() if str(k).startswith("top")})
    base_cols = ["model", "accuracy"] + topk_cols + ["macro_f1", "roc_auc_macro_ovr", "pr_auc_macro", "outdir"]
    other_cols = [c for c in df.columns if c not in base_cols]
    df = df[base_cols + other_cols]

    outdir.mkdir(parents=True, exist_ok=True)

    combined_csv = outdir / "summary_all_models.csv"
    df.to_csv(combined_csv, index=False)

    combined_json = outdir / "summary_all_models.json"
    with open(combined_json, "w") as f:
        json.dump(all_rows, f, indent=2)

    # If CV was used, also produce mean/std per model across folds
    if "fold" in df.columns:
        metrics_cols = [c for c in df.columns if c not in ["model", "outdir", "fold"]]
        agg = df.groupby("model")[metrics_cols].agg(["mean", "std"])  # multiindex columns
        # Flatten columns like ('accuracy','mean') → 'accuracy_mean'
        agg.columns = [f"{m}_{stat}" for m, stat in agg.columns]
        agg = agg.reset_index()
        agg_csv = outdir / "summary_cv_by_model.csv"
        agg.to_csv(agg_csv, index=False)
    return df


def main():
    args = parse_args()

    # Load arch map if provided and attach to args
    arch_map = {}
    if args.arch_map:
        with open(args.arch_map, "r") as f:
            arch_map = json.load(f)
    args.arch_map_dict = arch_map

    data_root = Path(args.data_root)
    ckpt_dir = Path(args.checkpoints_dir)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    device = get_device(args.device)

    dataset, class_names = build_dataset(
        data_root=data_root,
        img_size=args.img_size,
        center_crop=not args.no_center_crop,
    )
    dataset_num_classes = len(class_names)
    if args.num_classes is not None and args.num_classes != dataset_num_classes:
        print(f"[WARN] --num-classes ({args.num_classes}) differs from dataset classes ({dataset_num_classes}). Using dataset classes: {dataset_num_classes}.")

    # Ensure top-k values are valid for the dataset
    args.topk = [k for k in args.topk if k <= dataset_num_classes]
    if not args.topk:
        args.topk = [1]

    checkpoints = find_checkpoints(ckpt_dir)
    if not checkpoints:
        raise SystemExit(f"No checkpoints found in {ckpt_dir}. Expected files with extensions .pt, .pth, .ckpt")

    # Prepare targets for stratification
    if hasattr(dataset, "targets"):
        targets = np.array(dataset.targets)
    else:
        targets = np.array([s[1] for s in dataset.samples])

    all_rows: List[Dict] = []

    if args.cv_folds <= 1:
        # Single full-dataset evaluation
        loader = make_loader(dataset, batch_size=args.batch_size, num_workers=args.num_workers, indices=None)
        for ckpt in checkpoints:
            print(f"Evaluating {ckpt.name} ...")
            try:
                row = evaluate_checkpoint(ckpt, args, device, loader, class_names, fold_idx=None)
                all_rows.append(row)
                print(f"  -> Done. Accuracy={row['accuracy']:.4f}, MacroF1={row['macro_f1']:.4f}")
            except Exception as e:
                print(f"[ERROR] Failed on {ckpt.name}: {e}")
                all_rows.append({
                    "model": str(ckpt.relative_to(ckpt_dir)).replace("\\", "/"),
                    "accuracy": np.nan,
                    "macro_f1": np.nan,
                    "roc_auc_macro_ovr": np.nan,
                    "pr_auc_macro": np.nan,
                    "error": str(e),
                    "outdir": "",
                })
    else:
        print(f"[INFO] Running Stratified {args.cv_folds}-fold CV (shuffle={args.cv_shuffle}, seed={args.cv_seed})")
        skf = StratifiedKFold(n_splits=args.cv_folds, shuffle=args.cv_shuffle, random_state=args.cv_seed)
        for fold_idx, (_, val_idx) in enumerate(skf.split(np.zeros(len(targets)), targets), start=1):
            print(f"\n[INFO] Fold {fold_idx}/{args.cv_folds}: val size = {len(val_idx)}")
            loader = make_loader(dataset, batch_size=args.batch_size, num_workers=args.num_workers, indices=val_idx.tolist())
            for ckpt in checkpoints:
                print(f"Evaluating {ckpt.name} (fold {fold_idx}) ...")
                try:
                    row = evaluate_checkpoint(ckpt, args, device, loader, class_names, fold_idx=fold_idx)
                    all_rows.append(row)
                    print(f"  -> Done (fold {fold_idx}). Acc={row['accuracy']:.4f}, MacroF1={row['macro_f1']:.4f}")
                except Exception as e:
                    print(f"[ERROR] Failed on {ckpt.name} (fold {fold_idx}): {e}")
                    all_rows.append({
                        "model": str(ckpt.relative_to(ckpt_dir)).replace("\\", "/"),
                        "accuracy": np.nan,
                        "macro_f1": np.nan,
                        "roc_auc_macro_ovr": np.nan,
                        "pr_auc_macro": np.nan,
                        "error": str(e),
                        "outdir": "",
                        "fold": int(fold_idx),
                    })

    df = aggregate_and_save(all_rows, outdir)

    print("\nSaved combined results to:")
    print(f"  {outdir / 'summary_all_models.csv'}")
    print(f"  {outdir / 'summary_all_models.json'}")
    if "fold" in df.columns:
        print(f"  {outdir / 'summary_cv_by_model.csv'}  (mean/std across folds)")
    print("Per-model reports are in subfolders inside:", outdir)


if __name__ == "__main__":
    main()
