from typing import Optional, Tuple, Dict
import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# ----------------------------
# Grad-CAM (post-hoc explainer)
# ----------------------------
class GradCAM:
    """
    Post-hoc visualization. Hooks a target conv layer and produces CAM heatmaps.
    Usage:
        target = find_last_conv_layer(model)
        cam = GradCAM(model, target)
        maps = cam(input_tensor)  # (B,H,W) in [0,1]
        cam.remove_hooks()
    """
    def __init__(self, model: nn.Module, target_layer: nn.Module):
        self.model = model
        self.model.eval()
        self.target_layer = target_layer
        self.activations = None
        self.gradients = None

        self.fwd_handle = target_layer.register_forward_hook(self._forward_hook)
        if hasattr(target_layer, "register_full_backward_hook"):
            self.bwd_handle = target_layer.register_full_backward_hook(self._backward_hook)
        else:
            self.bwd_handle = target_layer.register_backward_hook(self._backward_hook_legacy)

    def _forward_hook(self, module, inputs, output):
        self.activations = output.detach()

    def _backward_hook(self, module, grad_input, grad_output):
        self.gradients = grad_output[0].detach()

    def _backward_hook_legacy(self, module, grad_input, grad_output):
        self.gradients = grad_output[0].detach()

    def remove_hooks(self):
        for h in (self.fwd_handle, self.bwd_handle):
            try:
                h.remove()
            except Exception:
                pass

    @torch.no_grad()
    def _safe_interpolate(self, x: torch.Tensor, size: Tuple[int, int]) -> torch.Tensor:
        return F.interpolate(x, size=size, mode="bilinear", align_corners=False)

    def __call__(self, input_tensor: torch.Tensor, class_idx: Optional[int] = None) -> np.ndarray:
        """
        input_tensor: (B,C,H,W), normalized as your model expects
        class_idx: None -> per-sample argmax; int -> same class for all; or LongTensor (B,)
        returns: np.ndarray (B,H,W) in [0,1]
        """
        device = next(self.model.parameters()).device
        x = input_tensor.to(device)

        self.model.zero_grad(set_to_none=True)
        logits = self.model(x)  # (B, num_classes)

        if class_idx is None:
            targets = logits.argmax(dim=1)
        elif isinstance(class_idx, int):
            targets = torch.full((logits.size(0),), class_idx, dtype=torch.long, device=device)
        else:
            targets = class_idx.to(device)

        selected = logits.gather(1, targets.view(-1, 1)).sum()
        self.model.zero_grad(set_to_none=True)
        selected.backward(retain_graph=True)

        grads = self.gradients
        acts = self.activations
        if grads is None or acts is None:
            raise RuntimeError("GradCAM hooks did not capture gradients/activations—check target layer.")

        weights = grads.mean(dim=(2, 3), keepdim=True)   # (B,C,1,1)
        cam = (weights * acts).sum(dim=1)                # (B,H',W')
        cam = F.relu(cam)

        cam = self._safe_interpolate(cam.unsqueeze(1), size=x.shape[-2:]).squeeze(1)

        cams = []
        for i in range(cam.shape[0]):
            c = cam[i]
            c = c - c.min()
            c = c / (c.max() + 1e-8)
            cams.append(c.detach().cpu().numpy())
        return np.stack(cams, axis=0)


# -------------
# CAM utilities
# -------------
def denormalize(img_tensor: torch.Tensor, mean: Tuple[float, ...], std: Tuple[float, ...]) -> torch.Tensor:
    """(C,H,W) -> (C,H,W) in [0,1]"""
    device = img_tensor.device
    mean_t = torch.tensor(mean, device=device).view(-1, 1, 1)
    std_t = torch.tensor(std, device=device).view(-1, 1, 1)
    x = img_tensor * std_t + mean_t
    return x.clamp(0, 1)

def find_last_conv_layer(model: nn.Module) -> nn.Module:
    last_conv = None
    for m in model.modules():
        if isinstance(m, nn.Conv2d):
            last_conv = m
    if last_conv is None:
        raise ValueError("No nn.Conv2d found; Grad-CAM requires a conv layer.")
    return last_conv

def _find_parent_and_name(model: nn.Module, target: nn.Module):
    """Return (parent_module, child_name) for `target` within `model`."""
    for parent_name, parent in model.named_modules():
        for child_name, child in parent.named_children():
            if child is target:
                return parent, child_name
    return None, None


# --------------------------------
# Trainable Attention (SE / CBAM)
# --------------------------------
class SEBlock(nn.Module):
    """Squeeze-and-Excitation: channel attention only."""
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, max(channels // reduction, 1), bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(max(channels // reduction, 1), channels, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, _, _ = x.shape
        y = self.pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y


class ChannelAttention(nn.Module):
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        mid = max(channels // reduction, 1)
        self.mlp = nn.Sequential(
            nn.Conv2d(channels, mid, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid, channels, 1, bias=False),
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.mlp(self.avg_pool(x))
        max_out = self.mlp(self.max_pool(x))
        out = avg_out + max_out
        return x * self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size: int = 7):
        super().__init__()
        assert kernel_size in (3, 7)
        padding = 3 if kernel_size == 7 else 1
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x_cat = torch.cat([avg_out, max_out], dim=1)
        attn = self.sigmoid(self.conv(x_cat))
        return x * attn


class CBAMBlock(nn.Module):
    """Convolutional Block Attention Module: channel + spatial."""
    def __init__(self, channels: int, reduction: int = 16, spatial_kernel: int = 7):
        super().__init__()
        self.ca = ChannelAttention(channels, reduction=reduction)
        self.sa = SpatialAttention(kernel_size=spatial_kernel)

    def forward(self, x):
        x = self.ca(x)
        x = self.sa(x)
        return x


# ----------------------------------------------------------
# Helpers to insert attention into an existing CNN backbone
# ----------------------------------------------------------
def attach_attention_to_last_conv(
    model: nn.Module,
    kind: str = "se",
    reduction: int = 16,
    cbam_kernel: int = 7,
) -> nn.Module:
    """
    Finds the LAST nn.Conv2d in `model` and wraps it as: Sequential(conv, AttentionBlock).
    Returns the modified model (in-place replacement).
    """
    last_conv = find_last_conv_layer(model)
    parent, name = _find_parent_and_name(model, last_conv)
    if parent is None:
        raise RuntimeError("Could not locate parent module of last Conv2d.")

    out_ch = last_conv.out_channels
    if kind.lower() == "se":
        attn = SEBlock(out_ch, reduction=reduction)
    elif kind.lower() == "cbam":
        attn = CBAMBlock(out_ch, reduction=reduction, spatial_kernel=cbam_kernel)
    else:
        raise ValueError(f"Unknown attention kind: {kind}. Use 'se' or 'cbam'.")

    wrapped = nn.Sequential(last_conv, attn)
    setattr(parent, name, wrapped)  # in-place patch
    return model


def attach_attention_to_named_layers(
    model: nn.Module,
    layer_names: Dict[str, str],
    reduction: int = 16,
    cbam_kernel: int = 7,
):
    """
    Attach attention after specific named submodules.
    layer_names: dict mapping submodule full-name -> kind ('se' or 'cbam')
      Example: {'features.6': 'cbam', 'layer4.1.conv2': 'se'}
    """
    # Build lookup of name -> module (and parent)
    name_to_module = dict(model.named_modules())
    for full_name, kind in layer_names.items():
        if full_name not in name_to_module:
            raise ValueError(f"Layer '{full_name}' not found in model.")
        target = name_to_module[full_name]
        parent, child_name = _find_parent_and_name(model, target)
        if parent is None:
            raise RuntimeError(f"Could not locate parent for '{full_name}'.")

        # Determine channels to size the attention block.
        if isinstance(target, nn.Conv2d):
            out_ch = target.out_channels
        elif hasattr(target, "out_channels"):
            out_ch = int(target.out_channels)  # custom block exposing out_channels
        else:
            # Fallback: try to infer via a dummy pass—safer to require conv
            raise ValueError(f"Layer '{full_name}' does not expose out_channels; attach to a Conv2d or supply a conv-like layer.")

        if kind.lower() == "se":
            attn = SEBlock(out_ch, reduction=reduction)
        elif kind.lower() == "cbam":
            attn = CBAMBlock(out_ch, reduction=reduction, spatial_kernel=cbam_kernel)
        else:
            raise ValueError(f"Unknown attention kind for '{full_name}': {kind}")

        setattr(parent, child_name, nn.Sequential(target, attn))

    return model


# -----------------------------------------
# Simple CAM logging helpers for validation
# -----------------------------------------
IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)

def save_sample_cams(model, batch, outdir, class_idx=None,
                     mean=IMAGENET_MEAN, std=IMAGENET_STD, max_samples=8):
    import os, numpy as np, torch
    os.makedirs(outdir, exist_ok=True)
    was_training = model.training
    model.eval()
    try:
        images, _labels = batch
        with torch.enable_grad():  # <— critical so Grad-CAM can backprop
            target_layer = find_last_conv_layer(model)
            cam = GradCAM(model, target_layer)
            maps = cam(images, class_idx=class_idx)
            cam.remove_hooks()

        imgs = images.detach().cpu()
        for i in range(min(len(imgs), max_samples)):
            np.save(os.path.join(outdir, f"cam_{i}.npy"), maps[i])
            rgb = denormalize(imgs[i], mean, std).permute(1, 2, 0).numpy()
            np.save(os.path.join(outdir, f"img_{i}.npy"), rgb)
    finally:
        if was_training:
            model.train()

def log_cams_for_all_models(models: Dict[str, nn.Module], val_loader, epoch: int, out_root: str = "cams"):
    """
    models: dict name -> model
    val_loader: torch DataLoader
    """
    sample_batch = next(iter(val_loader))
    for name, model in models.items():
        outdir = os.path.join(out_root, f"{name}_epoch{epoch:03d}")
        save_sample_cams(model, sample_batch, outdir)


__all__ = [
    "GradCAM",
    "SEBlock",
    "CBAMBlock",
    "attach_attention_to_last_conv",
    "attach_attention_to_named_layers",
    "find_last_conv_layer",
    "denormalize",
    "save_sample_cams",
    "log_cams_for_all_models",
    "IMAGENET_MEAN",
    "IMAGENET_STD",
]
