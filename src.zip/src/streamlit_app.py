import streamlit as st
import json, cv2, torch, sys
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms
from pathlib import Path
from typing import Optional, List, Dict, Iterable

# ---------------- Path setup ----------------
APP_DIR = Path(__file__).resolve().parent
if (APP_DIR / "src").exists():
    PROJECT_ROOT = APP_DIR
elif (APP_DIR.parent / "src").exists():
    PROJECT_ROOT = APP_DIR.parent
else:
    PROJECT_ROOT = APP_DIR

SRC_DIR = PROJECT_ROOT / "src"
if SRC_DIR.exists() and (str(SRC_DIR) not in sys.path):
    sys.path.append(str(SRC_DIR))

try:
    from model_utils import load_checkpoint
except Exception:
    from src.model_utils import load_checkpoint

# ---------------- Files & folders ----------------
CKPT_DIR = PROJECT_ROOT / "checkpoints"
CKPT_EXTS = {".pth", ".pt", ".ckpt"}

# Both datasets are 10-class now
DATASET_INFO = {
    "PlantVillage": {"num_classes": 10, "folders": ["full_training", "sub_training", "SE", "CBAM"]},
    "Combined_dataset": {"num_classes": 10, "folders": ["sub_training", "SE", "CBAM"]},  # no full_training
}

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD  = [0.229, 0.224, 0.225]

EVAL_TFMS = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
])

# ============================ Grad-CAM helpers ============================
def find_last_conv_layer(model: nn.Module) -> nn.Module:
    last = None
    for m in model.modules():
        if isinstance(m, nn.Conv2d):
            last = m
    if last is None:
        raise RuntimeError("No Conv2d layer found in model for Grad-CAM.")
    return last

class GradCAM:
    def __init__(self, model: nn.Module, target_layer: nn.Module):
        self.model = model
        self.target_layer = target_layer
        self.activations = None
        self.gradients = None
        self._fwd_hook = self.target_layer.register_forward_hook(self._save_activation)
        if hasattr(self.target_layer, "register_full_backward_hook"):
            self._bwd_hook = self.target_layer.register_full_backward_hook(self._save_gradient)
        else:
            self._bwd_hook = self.target_layer.register_backward_hook(self._save_gradient)

    def _save_activation(self, module, inp, out):
        self.activations = out

    def _save_gradient(self, module, grad_in, grad_out):
        self.gradients = grad_out[0]

    def remove_hooks(self):
        if self._fwd_hook is not None:
            try: self._fwd_hook.remove()
            except Exception: pass
        if self._bwd_hook is not None:
            try: self._bwd_hook.remove()
            except Exception: pass

    def __call__(self, x: torch.Tensor, class_idx: Optional[int] = None) -> np.ndarray:
        assert x.ndim == 4 and x.size(0) == 1, "Grad-CAM expects a single image batch (1, C, H, W)."
        self.model.zero_grad(set_to_none=True)
        with torch.enable_grad():
            logits = self.model(x)
            if class_idx is None:
                class_idx = int(torch.argmax(logits, dim=1).item())
            score = logits[:, class_idx].sum()
            score.backward(retain_graph=False)
        A = self.activations
        dA = self.gradients
        if A is None or dA is None:
            raise RuntimeError("Grad-CAM hooks did not capture activations/gradients.")
        weights = dA.mean(dim=(2, 3), keepdim=True)
        cam = (weights * A).sum(dim=1, keepdim=True)
        cam = F.relu(cam)
        cam = cam - cam.amin(dim=(2,3), keepdim=True)
        denom = cam.amax(dim=(2,3), keepdim=True).clamp(min=1e-6)
        cam = cam / denom
        cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)
        heat = cam.squeeze().detach().cpu().numpy()
        return heat

def denormalize(img_t: torch.Tensor, mean=IMAGENET_MEAN, std=IMAGENET_STD) -> np.ndarray:
    x = img_t.detach().cpu().clone()
    for c in range(3):
        x[c] = x[c]*std[c] + mean[c]
    x = x.clamp(0,1).permute(1,2,0).numpy()
    x = (x*255.0).round().astype(np.uint8)
    return x

def overlay_heatmap_on_rgb(rgb: np.ndarray, heat: np.ndarray, alpha: float = 0.45) -> np.ndarray:
    h = (heat * 255.0).round().astype(np.uint8)
    cmap = cv2.applyColorMap(h, cv2.COLORMAP_JET)
    cmap = cv2.cvtColor(cmap, cv2.COLOR_BGR2RGB)
    if (cmap.shape[0] != rgb.shape[0]) or (cmap.shape[1] != rgb.shape[1]):
        cmap = cv2.resize(cmap, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_CUBIC)
    over = cv2.addWeighted(rgb, 1.0, cmap, float(alpha), 0.0)
    return over

# ============================ UI ============================
st.set_page_config(page_title="Tomato Leaf Disease Classifier", page_icon="🍅", layout="wide")

with st.sidebar:
    st.header("⚙️ Settings")

    dataset_key = st.radio(
        "Dataset",
        ["PlantVillage", "Combined_dataset"],
        format_func=lambda k: f"{k} (10 classes)",
        horizontal=False,
    )
    EXPECTED_NCLS = DATASET_INFO[dataset_key]["num_classes"]

    folder_options = DATASET_INFO[dataset_key]["folders"]
    pretty_folder = {
        "full_training": "Full training",
        "sub_training": "Sub training",
        "SE": "Squeeze-and-Excitation",
        "CBAM": "CBAM",
    }
    folder_key = st.radio(
        "Model folder",
        folder_options,
        format_func=lambda k: f"{pretty_folder.get(k,k)} ({EXPECTED_NCLS} classes)",
        horizontal=False,
    )

    ARCH_CHOICES = [
        ("resnet18", "ResNet-18"),
        ("resnet50", "ResNet-50"),
        ("densenet121", "DenseNet-121"),
        ("mobilenet_v2", "MobileNet V2"),
        ("efficientnet_b0", "EfficientNet-B0"),
    ]
    arch_pretty = [b for a,b in ARCH_CHOICES]
    arch_idx = st.selectbox("Architecture (used for filename hints)", arch_pretty, index=0)
    arch = ARCH_CHOICES[arch_pretty.index(arch_idx)][0]

st.title("🍅 Tomato Leaf Disease Classifier")
st.caption("Supports PlantVillage and Combined_dataset — both 10-class — switchable CNN backbones + Grad-CAM")

ARCH_TO_CANDIDATES: Dict[str, List[str]] = {
    "resnet18": ["best_resnet18.pth", "best resnet18.pth"],
    "resnet50": ["best_resnet50.pth", "best resnet50.pth"],
    "densenet121": ["best_densenet121.pth", "best densenet121.pth"],
    "mobilenet_v2": ["best_mobilenet_v2.pth", "best mobilenet_v2.pth"],
    "efficientnet_b0": ["best_efficientb0.pth", "best_efficientnet_b0.pth", "best_efficientnetb0.pth"],
}

def _folder_candidates(dataset: str, folder: str) -> List[Path]:
    """
    Candidate directories (no legacy alias).
    1) checkpoints/<Dataset>/<Folder>
    2) checkpoints/<Folder>  (flat legacy but kept; no merged_sub_training)
    """
    return [CKPT_DIR / dataset / folder, CKPT_DIR / folder]

def _iter_files(paths: Iterable[Path]) -> Iterable[Path]:
    for base in paths:
        if base.exists():
            for p in base.rglob("*"):
                yield p

@st.cache_data(show_spinner=False)
def find_checkpoint(paths: List[Path], candidates: List[str]) -> Optional[Path]:
    cand_set = {c.lower() for c in candidates}
    hits = []
    for p in _iter_files(paths):
        if p.is_file() and p.suffix.lower() in CKPT_EXTS:
            if p.name.lower() in cand_set:
                hits.append(p)
    if hits:
        def score(x: Path):
            try:
                rel = x.relative_to(CKPT_DIR)
                depth = len(rel.parts)
            except Exception:
                depth = 999
            return (depth, -x.stat().st_mtime)
        hits.sort(key=score)
        return hits[0]
    return None

search_roots = _folder_candidates(dataset_key, folder_key)
ckpt_path = find_checkpoint(search_roots, ARCH_TO_CANDIDATES[arch])

if ckpt_path is None:
    pretty_names = ", ".join(ARCH_TO_CANDIDATES[arch])
    locs = "\n".join(f"- `{p}`" for p in search_roots)
    st.warning(
        f"**No checkpoint found** matching [{pretty_names}].\n\n"
        f"Search locations:\n{locs}\n\n"
        "Place one of the expected files in those folders."
    )
    st.stop()

@st.cache_resource(show_spinner=True)
def load_model(ckpt_path_str: str, num_classes: int):
    model, ckpt = load_checkpoint(ckpt_path_str, num_classes=num_classes)
    model.to(DEVICE).eval()
    return model, ckpt

# ---------- Load model (10-class) and require class_names from checkpoint ----------
try:
    model, ckpt = load_model(str(ckpt_path), num_classes=EXPECTED_NCLS)
    backbone = (ckpt.get("model_name") if isinstance(ckpt, dict) else None) or ckpt_path.stem.replace("best_", "")

    ckpt_classes = None
    if isinstance(ckpt, dict):
        ckpt_classes = ckpt.get("class_names")

    if not ckpt_classes or len(ckpt_classes) != EXPECTED_NCLS:
        raise RuntimeError(
            "Checkpoint must include `class_names` with 10 entries. "
            "Please re-save your checkpoint to include class_names."
        )

    classes = ckpt_classes

    try:
        rel_path = ckpt_path.relative_to(PROJECT_ROOT)
    except Exception:
        rel_path = ckpt_path

    st.success(
        f"Loaded: `{rel_path}` — **{dataset_key} → {folder_key}**, "
        f"arch **{backbone}**, classes **{len(classes)}**, device **{DEVICE.type.upper()}**"
    )

except Exception as e:
    st.error(
        f"Failed to load checkpoint `{ckpt_path}`.\n\n"
        f"{e}"
    )
    st.stop()

# ---------------- Inference UI ----------------
st.markdown("### Inference")
upl = st.file_uploader("Upload a tomato leaf image", type=["jpg","jpeg","png","bmp"])
if upl:
    file_bytes = np.frombuffer(upl.read(), np.uint8)
    img_bgr = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
    if img_bgr is None:
        st.error("Unable to read image.")
    else:
        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        st.image(img_rgb, caption="Input", use_container_width=True)

        x = EVAL_TFMS(img_rgb).unsqueeze(0).to(DEVICE)
        with torch.no_grad():
            logits = model(x)
            probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
            pred_idx = int(np.argmax(probs))
            pred_label = classes[pred_idx]
            conf = float(probs[pred_idx])

        st.subheader(f"Prediction: **{pred_label}** ({conf*100:.1f}% confidence)")
        guidance = {
            "Tomato___Bacterial_spot": "Consider copper-based bactericides; avoid overhead irrigation.",
            "Tomato___Early_blight": "Remove infected leaves; apply fungicide; rotate crops.",
            "Tomato___Late_blight": "Apply fungicide promptly; remove infected plants; avoid persistent humidity.",
            "Tomato___Leaf_Mold": "Improve ventilation; avoid overhead watering; consider fungicide.",
            "Tomato___Septoria_leaf_spot": "Remove debris; use resistant varieties; apply fungicide as needed.",
            "Tomato___Spider_mites_Two_spotted_spider_mite": "Rinse leaves; consider miticides; encourage predators.",
            "Tomato___Target_Spot": "Use preventative fungicides; remove infected foliage.",
            "Tomato___Tomato_Yellow_Leaf_Curl_Virus": "Control whiteflies; remove infected plants; use resistant cultivars.",
            "Tomato___Tomato_mosaic_virus": "Sanitize tools; remove infected plants; control weeds.",
            "Tomato___healthy": "No action needed; continue monitoring."
        }
        st.info(guidance.get(
            pred_label,
            "Follow integrated pest management best practices; consult local extension services."
        ))

        # ---------------- Grad-CAM UI ----------------
        st.markdown("---")
        st.subheader("Grad-CAM explanation")
        col1, col2, col3 = st.columns([1,1,1])
        with col1:
            enable_cam = st.checkbox("Show Grad-CAM", value=True)
        with col2:
            on_original = st.checkbox("Overlay on original size", value=False,
                                      help="If off, shows overlay on the 224×224 model crop.")
        with col3:
            alpha = st.slider("Heatmap alpha", min_value=0.2, max_value=0.9, value=0.45, step=0.05)

        cam_mode = st.radio("Explain…", ["Predicted class", "Choose a class"], horizontal=True)
        force_idx: Optional[int] = None
        if cam_mode == "Choose a class":
            force_label = st.selectbox("Class", classes, index=pred_idx)
            force_idx = classes.index(force_label)

        if enable_cam:
            try:
                target_layer = find_last_conv_layer(model)
                cam = GradCAM(model, target_layer)
                class_for_cam = pred_idx if force_idx is None else force_idx
                heat = cam(x, class_idx=class_for_cam)

                rgb_224 = denormalize(x[0])
                base_rgb = img_rgb if on_original else rgb_224
                if (heat.shape[0] != base_rgb.shape[0]) or (heat.shape[1] != base_rgb.shape[1]):
                    heat_resized = cv2.resize(heat, (base_rgb.shape[1], base_rgb.shape[0]), interpolation=cv2.INTER_CUBIC)
                else:
                    heat_resized = heat
                overlay = overlay_heatmap_on_rgb(base_rgb, heat_resized, alpha=alpha)

                title = f"CAM for: {classes[class_for_cam]}"
                st.image(overlay, caption=title, use_container_width=True)
            except Exception as e:
                st.warning(f"Grad-CAM failed: {e}")
else:
    st.info("Upload an image to run a prediction.")
