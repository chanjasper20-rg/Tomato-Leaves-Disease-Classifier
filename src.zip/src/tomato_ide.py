import argparse, json
from pathlib import Path
import os
import pandas as pd
import torch
from torch import nn, optim
from torch.utils.data import DataLoader
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from sklearn.model_selection import StratifiedShuffleSplit

from src.data_utils import build_df, stratified_80_10_10, describe_splits
from src.dataset_cv import TomatoDataset, default_transforms
from src.model_utils import create_model, save_checkpoint, load_checkpoint, list_models

#Attention & grad-cam helpers
from src.attention_cam import (
    attach_attention_to_last_conv,
    save_sample_cams,
    IMAGENET_MEAN, IMAGENET_STD,
    GradCAM, find_last_conv_layer, denormalize,
)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

ROOT = Path(__file__).resolve().parents[1]
SPLITS_DIR = ROOT / "splits"
CKPT_DIR = ROOT / "checkpoints"
CKPT_FULL_DIR = CKPT_DIR / "full_training"
CKPT_SUB_DIR  = CKPT_DIR / "sub_training"
METRICS_DIR = ROOT / "Latest_Metrics"
CLASS_MAP_PATH = ROOT / "class_mapping.json"

def _resolve_ckpt_for(args, default_model: str = "resnet18"):
    # Preferred regime from args (train uses --training-mode, eval/predict use --regime)
    regime = getattr(args, "regime", None) or getattr(args, "training_mode", None)

    # If user provided a checkpoint path
    if getattr(args, "checkpoint", None):
        p = Path(args.checkpoint)
        if p.is_absolute():
            return p

        # Allow "checkpoints/..." absolute-ish project-relative paths
        if p.parts and p.parts[0] == "checkpoints":
            return ROOT / p  # keep full nested structure

        # Relative under known subfolders: "full_training/..." or "sub_training/..."
        if p.parts and p.parts[0] in ("full_training", "sub_training"):
            return CKPT_DIR / p

        # Try common locations by filename only
        for candidate in (CKPT_FULL_DIR / p.name, CKPT_SUB_DIR / p.name, CKPT_DIR / p.name):
            if candidate.exists():
                return candidate

        # Fall back to regime if provided
        if regime == "full":
            return CKPT_FULL_DIR / p.name
        if regime == "sub":
            return CKPT_SUB_DIR / p.name
        return CKPT_DIR / p.name

    # Otherwise infer from model name
    model_name = getattr(args, "model", None) or default_model
    fname = f"best_{model_name}.pth"
    if regime == "full":
        return CKPT_FULL_DIR / fname
    if regime == "sub":
        return CKPT_SUB_DIR / fname

    # Auto-detect existing file; otherwise prefer full_training by default
    for candidate in (CKPT_FULL_DIR / fname, CKPT_SUB_DIR / fname, CKPT_DIR / fname):
        if candidate.exists():
            return candidate
    return CKPT_FULL_DIR / fname

def cmd_prepare(args):
    df = build_df(args.data_dir)
    if df.empty:
        print("No images found under:", args.data_dir)
        return
    train_df, val_df, test_df = stratified_80_10_10(df, seed=args.seed)
    SPLITS_DIR.mkdir(exist_ok=True, parents=True)
    train_df.to_csv(SPLITS_DIR / "train.csv", index=False)
    val_df.to_csv(SPLITS_DIR / "val.csv", index=False)
    test_df.to_csv(SPLITS_DIR / "test.csv", index=False)

    classes = sorted(df["label"].unique())
    idx_to_label = {i:c for i,c in enumerate(classes)}
    CLASS_MAP_PATH.write_text(json.dumps(idx_to_label, indent=2))

    print(describe_splits(train_df, val_df, test_df))
    print("Wrote:", SPLITS_DIR / "train.csv", SPLITS_DIR / "val.csv", SPLITS_DIR / "test.csv")
    print("Wrote:", CLASS_MAP_PATH)

def _load_splits():
    train_df = pd.read_csv(SPLITS_DIR / "train.csv")
    val_df   = pd.read_csv(SPLITS_DIR / "val.csv")
    test_df  = pd.read_csv(SPLITS_DIR / "test.csv")
    classes = sorted(pd.concat([train_df["label"], val_df["label"], test_df["label"]]).unique())
    label_to_idx = {c:i for i,c in enumerate(classes)}
    return train_df, val_df, test_df, classes, label_to_idx

def _load_partial_weights(model: nn.Module, ckpt_path: Path) -> None:
    obj = torch.load(ckpt_path, map_location="cpu")

    # Our save_checkpoint stores {"model_state_dict": ...}; otherwise assume a raw state_dict
    sd = obj.get("model_state_dict", obj if isinstance(obj, dict) else None)
    if not isinstance(sd, dict):
        print(f"[init] Unsupported checkpoint format: {ckpt_path.name}; skipping init.")
        return

    model_sd = model.state_dict()
    pruned = {}
    dropped = []

    for k, v in sd.items():
        if k in model_sd and tuple(model_sd[k].shape) == tuple(v.shape):
            pruned[k] = v
        else:
            dropped.append(k)

    # Now load only the compatible keys
    res = model.load_state_dict(pruned, strict=False)
    missing = getattr(res, "missing_keys", [])
    unexpected = getattr(res, "unexpected_keys", [])

    print(f"[init] Loaded from {ckpt_path} ({len(pruned)} tensors)")
    if dropped:
        print(f"[init] skipped {len(dropped)} keys with shape mismatch (e.g., classifier/head)")
    if missing:
        print(f"[init] missing keys: {len(missing)} (expected for new attention/head)")
    if unexpected:
        print(f"[init] unexpected keys: {len(unexpected)}")

def cmd_train(args):
    train_df, val_df, _, classes, label_to_idx = _load_splits()

    # --- Optional STRATIFIED subset of the training set (total images across all classes) ---
    if args.subset is not None:
        desired = int(args.subset)
        if desired < len(classes):
            raise ValueError(f"--subset must be at least the number of classes ({len(classes)}); got {desired}.")
        total = len(train_df)
        if desired >= total:
            print(f"--subset={desired} >= train size ({total}); using full training set.")
        else:
            frac = desired / total
            sss = StratifiedShuffleSplit(n_splits=1, train_size=frac, random_state=getattr(args, "seed", 42))
            idx_sub, _ = next(sss.split(train_df, train_df["label"]))
            train_df = train_df.iloc[idx_sub].reset_index(drop=True)
            print(f"Using stratified subset: {len(train_df)} samples across {len(classes)} classes.")

    train_tfms, eval_tfms = default_transforms()
    train_ds = TomatoDataset(train_df, label_to_idx, transform=train_tfms)
    val_ds   = TomatoDataset(val_df,   label_to_idx, transform=eval_tfms)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=2, pin_memory=True)
    val_loader   = DataLoader(val_ds,   batch_size=args.batch_size, shuffle=False, num_workers=2, pin_memory=True)

    model = create_model(args.model, num_classes=len(classes)).to(DEVICE)

    #insert trainable attention if requested
    if getattr(args, "attention", "none") != "none":
        try:
            model = attach_attention_to_last_conv(
                model, kind=args.attention,
                reduction=args.attn_reduction,
                cbam_kernel=args.cbam_kernel
            )
            print(f"[attention] Attached {args.attention.upper()} to last Conv2d.")
        except Exception as e:
            print("[attention] Could not attach attention:", e)

    # ---- Optional: initialize from a previous checkpoint (no attention there)
    if getattr(args, "init_checkpoint", None):
        init_p = Path(args.init_checkpoint)
        if not init_p.is_absolute():
            # allow relative to checkpoints/ folders, mirroring _resolve_ckpt_for logic
            cand = [init_p,
                    CKPT_DIR / init_p,
                    CKPT_FULL_DIR / init_p.name,
                    CKPT_SUB_DIR / init_p.name]
            init_p = next((c for c in cand if c.exists()), init_p)
        if init_p.exists():
            _load_partial_weights(model, init_p)
        else:
            print(f"[init] checkpoint not found: {init_p}")

    #freeze backbone (train only attention + classifier)
    if args.freeze_backbone:
        for n, p in model.named_parameters():
            # keep attention & classifier trainable; freeze the rest
            if any(k in n.lower() for k in ("se", "cbam", "attention", "classifier", "fc")):
                p.requires_grad = True
            else:
                p.requires_grad = False

    criterion = nn.CrossEntropyLoss()
    # Split params to give a (usually higher) LR to attention + head
    attn_head, backbone = [], []
    for n, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if any(k in n.lower() for k in ("se", "cbam", "attention", "classifier", "fc")):
            attn_head.append(p)
        else:
            backbone.append(p)

    lr_backbone = args.lr_backbone if args.lr_backbone is not None else args.lr
    lr_head = args.lr_head if args.lr_head is not None else args.lr

    optimizer = optim.AdamW(
        [{"params": backbone, "lr": lr_backbone},
         {"params": attn_head, "lr": lr_head}],
        weight_decay=1e-4
    )

    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=10)

    best_acc = -1.0
    wait = args.patience
    history = []

    CKPT_DIR.mkdir(parents=True, exist_ok=True)
    CKPT_FULL_DIR.mkdir(parents=True, exist_ok=True)
    CKPT_SUB_DIR.mkdir(parents=True, exist_ok=True)
    out_dir = CKPT_FULL_DIR if args.training_mode == "full" else CKPT_SUB_DIR

    if args.output is None:
        ckpt_out = out_dir / f"best_{args.model}.pth"
    else:
        p = Path(args.output)
        s = str(args.output)
        is_dir_hint = s.endswith(("/", "\\"))  # treat trailing slash as dir hint on any OS
        if (p.exists() and p.is_dir()) or is_dir_hint:
            ckpt_out = p / f"best_{args.model}.pth"
        else:
            ckpt_out = p if p.is_absolute() else out_dir / p.name

        ckpt_out.parent.mkdir(parents=True, exist_ok=True)

    for ep in range(1, args.epochs+1):
        model.train()
        tr_loss=0.0; tr_correct=0; tr_total=0
        for imgs, labels in train_loader:
            imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            logits = model(imgs)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()
            tr_loss += loss.item()*imgs.size(0)
            tr_correct += (logits.argmax(1)==labels).sum().item()
            tr_total += labels.size(0)
        tr_loss/=tr_total; tr_acc=tr_correct/tr_total

        model.eval()
        val_loss=0.0; val_correct=0; val_total=0
        with torch.no_grad():
            for imgs, labels in val_loader:
                imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
                logits = model(imgs)
                loss = criterion(logits, labels)
                val_loss += loss.item()*imgs.size(0)
                val_correct += (logits.argmax(1)==labels).sum().item()
                val_total += labels.size(0)
        val_loss/=val_total; val_acc=val_correct/val_total
        scheduler.step()
        history.append({"epoch": ep, "train_loss": tr_loss, "train_acc": tr_acc, "val_loss": val_loss, "val_acc": val_acc})
        print(f"Epoch {ep:02d} | train loss {tr_loss:.4f} acc {tr_acc:.4f} | val loss {val_loss:.4f} acc {val_acc:.4f}")

        # >>> NEW: optional Grad-CAM logging every N epochs
        if getattr(args, "cam_interval", 0) and (ep % args.cam_interval == 0):
            sample_batch = next(iter(val_loader))
            class_idx = None
            if getattr(args, "cam_class", None):
                if args.cam_class not in label_to_idx:
                    print(f"[CAM] class '{args.cam_class}' not found; available: {sorted(label_to_idx.keys())}")
                else:
                    class_idx = label_to_idx[args.cam_class]
            cam_root = ROOT / "cams"
            outdir = cam_root / f"{args.model}_epoch{ep:03d}"
            save_sample_cams(
                model, sample_batch, str(outdir),
                class_idx=class_idx, mean=IMAGENET_MEAN, std=IMAGENET_STD,
                max_samples=getattr(args, "cam_samples", 8)
            )
            print(f"[CAM] Saved heatmaps to {outdir}")

        if val_acc > best_acc:
            best_acc = val_acc
            save_checkpoint(model, classes, str(ckpt_out), model_name=args.model)
            wait = args.patience
        else:
            wait -= 1
            if wait == 0:
                print("Early stopping.")
                break

    pd.DataFrame(history).to_csv(ROOT / "Latest_Training_History.csv", index=False)
    print("Model used:", model)
    print("Best val acc:", best_acc)
    print("Saved checkpoint:", ckpt_out)

def cmd_eval(args):
    import numpy as np, textwrap
    _, _, test_df, classes, label_to_idx = _load_splits()
    _, eval_tfms = default_transforms()

    test_loader = DataLoader(
        TomatoDataset(test_df, label_to_idx, transform=eval_tfms),
        batch_size=args.batch_size, shuffle=False, num_workers=2, pin_memory=True
    )

    # Fixed: pass default model token without 'best_' prefix
    ckpt_path = _resolve_ckpt_for(args, default_model="resnet18")
    if not ckpt_path.exists():
        print(f"Checkpoint not found: {ckpt_path}")
        return

    model, ckpt = load_checkpoint(str(ckpt_path), num_classes=len(classes))
    model.to(DEVICE).eval()

    y_true, y_pred = [], []
    with torch.no_grad():
        for imgs, labels in test_loader:
            imgs = imgs.to(DEVICE)
            logits = model(imgs)
            y_pred.extend(logits.argmax(1).cpu().numpy().tolist())
            y_true.extend(labels.numpy().tolist())

    # ---- Latest_Metrics
    acc = accuracy_score(y_true, y_pred)
    print("Test accuracy:", acc)

    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(classes))))
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)
    cm_norm = np.nan_to_num(cm_norm)

    # ---- make pretty class labels
    def pretty(lbl: str) -> str:
        lbl = lbl.replace("Tomato___", "Tomato ").replace("_", " ")
        return "\n".join(textwrap.wrap(lbl, width=18))
    disp_labels = [pretty(c) for c in classes]

    from sklearn.metrics import ConfusionMatrixDisplay
    import matplotlib.pyplot as plt
    METRICS_DIR.mkdir(parents=True, exist_ok=True)

    # COUNTS
    fig1, ax1 = plt.subplots(figsize=(16, 12), dpi=200)
    disp_counts = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=disp_labels)
    disp_counts.plot(include_values=True, cmap="Blues", ax=ax1, colorbar=True, values_format="d")
    ax1.set_title("Confusion Matrix (Counts)", fontsize=16)
    ax1.set_xlabel("Predicted", fontsize=13)
    ax1.set_ylabel("True", fontsize=13)
    ax1.tick_params(axis="x", labelrotation=45, labelsize=10)
    ax1.tick_params(axis="y", labelsize=10)
    fig1.tight_layout()
    fig1.savefig(METRICS_DIR / "confusion_matrix_counts.png")
    import matplotlib.pyplot as plt # just to ensure close if redeclared
    import matplotlib
    plt.close(fig1)

    # NORMALIZED
    fig2, ax2 = plt.subplots(figsize=(16, 12), dpi=200)
    disp_norm = ConfusionMatrixDisplay(confusion_matrix=cm_norm, display_labels=disp_labels)
    disp_norm.plot(include_values=True, cmap="Blues", ax=ax2, colorbar=True)
    # format overlay numbers
    for t in ax2.texts:
        try:
            t.set_text(f"{float(t.get_text()):.2f}")
        except Exception:
            pass
    ax2.set_title("Confusion Matrix (Normalized by True Class)", fontsize=16)
    ax2.set_xlabel("Predicted", fontsize=13)
    ax2.set_ylabel("True", fontsize=13)
    ax2.tick_params(axis="x", labelrotation=45, labelsize=10)
    ax2.tick_params(axis="y", labelsize=10)
    fig2.tight_layout()
    fig2.savefig(METRICS_DIR / "confusion_matrix_normalized.png")
    plt.close(fig2)

    # CSV exports
    import pandas as pd, json
    pd.DataFrame(cm, index=classes, columns=classes).to_csv(METRICS_DIR / "confusion_matrix_counts.csv")
    pd.DataFrame(cm_norm, index=classes, columns=classes).to_csv(METRICS_DIR / "confusion_matrix_normalized.csv")
    rpt = classification_report(y_true, y_pred, target_names=classes, output_dict=True)
    (METRICS_DIR / "test_report.json").write_text(json.dumps({"accuracy": float(acc), "report": rpt}, indent=2))

    print("Saved:")
    print("-", METRICS_DIR / "confusion_matrix_counts.png")
    print("-", METRICS_DIR / "confusion_matrix_normalized.png")
    print("-", METRICS_DIR / "confusion_matrix_counts.csv")
    print("-", METRICS_DIR / "confusion_matrix_normalized.csv")
    print("-", METRICS_DIR / "test_report.json")

def cmd_predict(args):
    import cv2, numpy as np
    from torchvision import transforms

    idx_to_label = json.loads(Path(CLASS_MAP_PATH).read_text())
    classes = [idx_to_label[str(i)] if str(i) in idx_to_label else idx_to_label[i] for i in range(len(idx_to_label))]

    # Use the same resolver for consistency
    ckpt_path = _resolve_ckpt_for(args, default_model="resnet18")
    model, ckpt = load_checkpoint(str(ckpt_path), num_classes=len(classes))
    model.to(DEVICE).eval()

    tfm = transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225]),
    ])

    img_bgr = cv2.imread(args.image)
    if img_bgr is None:
        print("Could not read image:", args.image)
        return
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    x = tfm(img_rgb).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        logits = model(x)
        probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
        pred_idx = int(np.argmax(probs))
        pred_label = classes[pred_idx]
        conf = float(probs[pred_idx])
    print(f"Prediction: {pred_label} ({conf*100:.1f}% confidence)")

def cmd_predict_cam(args):
    import cv2, numpy as np
    from torchvision import transforms
    import matplotlib.pyplot as plt

    # Load class mapping
    idx_to_label = json.loads(Path(CLASS_MAP_PATH).read_text())
    classes = [idx_to_label[str(i)] if str(i) in idx_to_label else idx_to_label[i]
               for i in range(len(idx_to_label))]

    # Resolve checkpoint and load
    ckpt_path = _resolve_ckpt_for(args, default_model="resnet18")
    if not ckpt_path.exists():
        print(f"Checkpoint not found: {ckpt_path}")
        return
    model, _ = load_checkpoint(str(ckpt_path), num_classes=len(classes))
    model.to(DEVICE).eval()

    # Image transforms (match eval)
    tfm = transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225]),
    ])

    img_bgr = cv2.imread(args.image)
    if img_bgr is None:
        print("Could not read image:", args.image)
        return
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    x = tfm(img_rgb).unsqueeze(0).to(DEVICE)

    # Forward to get predicted class (or force one)
    with torch.no_grad():
        logits = model(x)
        probs = torch.softmax(logits, dim=1)[0]
        pred_idx = int(torch.argmax(probs).item())
    force_idx = None
    if getattr(args, "cam_force_class", None):
        if args.cam_force_class in classes:
            force_idx = classes.index(args.cam_force_class)
        else:
            print(f"[CAM] class '{args.cam_force_class}' not found; using predicted.")

    # Grad-CAM
    target = find_last_conv_layer(model)
    cam = GradCAM(model, target)
    maps = cam(x, class_idx=force_idx if force_idx is not None else pred_idx)  # (1,H,W)
    heat = maps[0]
    cam.remove_hooks()

    # Denormalize original
    rgb = denormalize(x[0].detach().cpu(), IMAGENET_MEAN, IMAGENET_STD).permute(1, 2, 0).numpy()
    rgb = (rgb * 255).astype("uint8")

    # Save overlay using matplotlib — no title, no margins/whitespace
    METRICS_DIR.mkdir(parents=True, exist_ok=True)
    out_png = Path(args.out) if getattr(args, "out", None) else METRICS_DIR / "gradcam_predict.png"

    h, w = heat.shape
    fig = plt.figure(figsize=(w / 100, h / 100), dpi=100)
    ax = fig.add_axes([0, 0, 1, 1])  # fill canvas; no borders
    ax.axis("off")
    ax.imshow(rgb)
    ax.imshow(heat, alpha=0.45, cmap="jet")
    fig.savefig(out_png, dpi=100)  # no title = no white band
    plt.close(fig)

    # Terminal-only output
    print(f"Saved: {out_png}")
    print(f"Prediction: {classes[pred_idx]}")
    print(f"Confidence: {float(probs[pred_idx]) * 100:.1f}%")


def build_parser():
    p = argparse.ArgumentParser(description="Tomato Leaf Disease Classification (PlantVillage Tomato)")
    sub = p.add_subparsers(dest="command", required=True)

    sp = sub.add_parser("prepare", help="Scan dataset and create 80/10/10 stratified splits")
    sp.add_argument("--data-dir", required=True, help="Path to dataset directory with Tomato___* class folders")
    sp.add_argument("--seed", type=int, default=42, help="Random seed")
    sp.set_defaults(func=cmd_prepare)

    st = sub.add_parser("train", help="Train model on the training split, validate on val split")
    st.add_argument("--model", choices=list_models(), default="resnet18", help="CNN models to use")
    st.add_argument("--training-mode", choices=["full", "sub"], default="full", help="Saves checkpoints to checkpoints/<training-mode>/")
    st.add_argument("--epochs", type=int, default=10)
    st.add_argument("--batch-size", type=int, default=32)
    st.add_argument("--lr", type=float, default=1e-4)
    st.add_argument("--patience", type=int, default=3)
    st.add_argument("--subset", type=int, default=None, help="Stratified subset size for training (total images across all classes)")
    st.add_argument("--seed", type=int, default=42, help="Random seed for subset sampling")
    st.add_argument("--output", type=str, default=None, help="Path to save checkpoint (default checkpoints/best_<model>.pth)")

    #Attention and CAM flags
    st.add_argument("--attention", choices=["none", "se", "cbam"], default="none", help="Insert a trainable attention block after the last conv.")
    st.add_argument("--attn-reduction", type=int, default=16, help="SE/CBAM channel reduction.")
    st.add_argument("--cbam-kernel", type=int, choices=[3, 7], default=7, help="CBAM spatial kernel.")
    st.add_argument("--cam-interval", type=int, default=0, help="Every N epochs, log Grad-CAMs on a small val batch (0=off).")
    st.add_argument("--cam-samples", type=int, default=8, help="How many CAMs to save per log step.")
    st.add_argument("--cam-class", type=str, default=None, help="If set, force CAMs for this class name instead of predicted class.")
    st.add_argument("--init-checkpoint", type=str, default=None, help="Initialize weights from this checkpoint before training (strict=False).")
    st.add_argument("--freeze-backbone", action="store_true", help="Freeze backbone; only train attention + classifier head.")
    st.add_argument("--lr-backbone", type=float, default=None, help="Optional LR for backbone params (defaults to --lr if unset).")
    st.add_argument("--lr-head", type=float, default=None, help="Optional LR for attention + classifier head (defaults to --lr if unset).")

    st.set_defaults(func=cmd_train)

    se = sub.add_parser("eval", help="Evaluate a checkpoint on the test split")
    se.add_argument("--batch-size", type=int, default=32)
    se.add_argument("--checkpoint", type=str, default=None, help="Filename in checkpoints/ to load")
    se.add_argument("--model", choices=list_models(), default=None, help="If no --checkpoint, infer checkpoints/best_<model>.pth")
    se.add_argument("--regime", choices=["full", "sub"], default=None, help="Where to look by default if inferring checkpoint (full_training or sub_training).")
    se.set_defaults(func=cmd_eval)

    spred = sub.add_parser("predict", help="Predict a single image using a checkpoint")
    spred.add_argument("--image", required=True, help="Path to a tomato leaf image")
    spred.add_argument("--checkpoint", type=str, default=None, help="Filename in checkpoints/ to load")
    spred.add_argument("--model", choices=list_models(), default=None, help="If no --checkpoint, infer checkpoints/best_<model>.pth")
    spred.add_argument("--regime", choices=["full", "sub"], default=None, help="Where to look by default if inferring checkpoint (full_training or sub_training).")
    spred.set_defaults(func=cmd_predict)

    #Predict-cam command
    spcam = sub.add_parser("predict-cam", help="Predict + save a Grad-CAM overlay for a single image")
    spcam.add_argument("--image", required=True, help="Path to a tomato leaf image")
    spcam.add_argument("--checkpoint", type=str, default=None, help="Filename in checkpoints/ to load")
    spcam.add_argument("--model", choices=list_models(), default=None,
                       help="If no --checkpoint, infer checkpoints/best_<model>.pth")
    spcam.add_argument("--regime", choices=["full", "sub"], default=None,
                       help="Where to look by default if inferring checkpoint.")
    spcam.add_argument("--class", dest="cam_force_class", type=str, default=None,
                       help="Force CAM for this class name (else use predicted).")
    spcam.add_argument("--out", type=str, default=None,
                       help="Output PNG path (default Latest_Metrics/gradcam_predict.png)")
    spcam.set_defaults(func=cmd_predict_cam)

    return p

def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
