from typing import Dict, Optional, Tuple
import cv2
import pandas as pd
from torch.utils.data import Dataset
from torchvision import transforms as T
import torch

class TomatoDataset(Dataset):
    def __init__(self, df: pd.DataFrame, label_to_idx: Dict[str, int], transform: Optional[T.Compose] = None):
        self.df = df.reset_index(drop=True)
        self.label_to_idx = label_to_idx
        self.transform = transform

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        row = self.df.iloc[idx]
        img = cv2.imread(row["path"])
        if img is None:
            raise RuntimeError(f"Failed to read image: {row['path']}")
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, (256, 256), interpolation=cv2.INTER_AREA)
        if self.transform:
            img = self.transform(img)
        label = self.label_to_idx[row["label"]]
        return img, label

def default_transforms():
    train_tfms = T.Compose([
        T.ToPILImage(),
        T.RandomResizedCrop(224, scale=(0.8, 1.0)),
        T.RandomHorizontalFlip(),
        T.ColorJitter(0.2, 0.2, 0.2, 0.05),
        T.ToTensor(),
        T.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225]),
    ])
    eval_tfms = T.Compose([
        T.ToPILImage(),
        T.Resize(256),
        T.CenterCrop(224),
        T.ToTensor(),
        T.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225]),
    ])
    return train_tfms, eval_tfms