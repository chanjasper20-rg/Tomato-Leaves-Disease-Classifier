from torch import nn
from torchvision import models
from datetime import datetime

class ResNet18Classifier:
    name = "resnet18"
    def build(self, num_classes: int) -> nn.Module:
        m = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
        in_features = m.fc.in_features
        m.fc = nn.Linear(in_features, num_classes)
        return m

class ResNet50Classifier:
    name = "resnet50"
    def build(self, num_classes: int) -> nn.Module:
        m = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
        in_features = m.fc.in_features
        m.fc = nn.Linear(in_features, num_classes)
        return m

class MobileNetV2Classifier:
    name = "mobilenet_v2"
    def build(self, num_classes: int) -> nn.Module:
        m = models.mobilenet_v2(weights=models.MobileNet_V2_Weights.DEFAULT)
        in_features = m.classifier[-1].in_features
        m.classifier[-1] = nn.Linear(in_features, num_classes)
        return m

class EfficientNetB0Classifier:
    name = "efficientnet_b0"
    def build(self, num_classes: int) -> nn.Module:
        m = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.DEFAULT)
        in_features = m.classifier[-1].in_features
        m.classifier[-1] = nn.Linear(in_features, num_classes)
        return m

class DenseNet121Classifier:
    name = "densenet121"
    def build(self, num_classes: int) -> nn.Module:
        m = models.densenet121(weights=models.DenseNet121_Weights.DEFAULT)
        in_features = m.classifier.in_features
        m.classifier = nn.Linear(in_features, num_classes)
        return m

MODEL_BUILDERS = {
    ResNet18Classifier.name: ResNet18Classifier(),
    ResNet50Classifier.name: ResNet50Classifier(),
    MobileNetV2Classifier.name: MobileNetV2Classifier(),
    EfficientNetB0Classifier.name: EfficientNetB0Classifier(),
    DenseNet121Classifier.name: DenseNet121Classifier(),
}

def list_models():
    return sorted(MODEL_BUILDERS.keys())

def create_resnet18(num_classes: int) -> nn.Module:
    return ResNet18Classifier().build(num_classes)

def create_model(model_name: str, num_classes: int) -> nn.Module:
    if model_name not in MODEL_BUILDERS:
        raise ValueError(f"Unknown model '{model_name}'. Available: {list_models()}")
    return MODEL_BUILDERS[model_name].build(num_classes)

def save_checkpoint(model, class_names, path, model_name: str, extra: dict | None = None):
    """
    Save a PyTorch checkpoint with essential metadata so UIs (Streamlit) can show backbone info.
    """
    ckpt = {
        "state_dict": model.state_dict(),
        "model_name": model_name,
        "num_classes": len(class_names),
        "class_names": list(class_names),
        "framework": "pytorch",
        "pytorch_version": torch.__version__,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    if extra:
        ckpt.update(extra)

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(ckpt, path)

from pathlib import Path
from collections import OrderedDict
import torch

# Allow-list needed class for safe loads (PyTorch 2.6+)
try:
    from torch.serialization import add_safe_globals
    import torch.torch_version as torch_version
    add_safe_globals([torch_version.TorchVersion])
except Exception:
    pass

def _strip_prefix(sd: dict, prefix: str) -> dict:
    if isinstance(sd, dict) and sd and all(isinstance(k, str) for k in sd.keys()):
        if all(k.startswith(prefix) for k in sd.keys()):
            return OrderedDict((k[len(prefix):], v) for k, v in sd.items())
    return sd

def load_checkpoint(path: str | Path, num_classes: int):
    """
    Robust checkpoint loader for PyTorch 2.6+:
    - Try weights_only=True with allow-listed globals
    - Fallback to weights_only=False (ONLY for trusted files)
    - Accept raw state_dict or full dict with metadata
    """
    path = Path(path)

    # --- 1) Try safe load first
    ckpt = None
    try:
        ckpt = torch.load(path, map_location="cpu", weights_only=True)
        # If it's a raw state_dict (all tensors), wrap it so downstream code works
        if isinstance(ckpt, dict) and ckpt and all(isinstance(v, torch.Tensor) for v in ckpt.values()):
            ckpt = {"state_dict": ckpt}
    except Exception as e_safe:
        # --- 2) Trusted fallback (only for your own files)
        ckpt = torch.load(path, map_location="cpu", weights_only=False)

    # --- 3) Infer metadata if missing
    model_name = ckpt.get("model_name")
    if not model_name:
        stem = path.stem
        model_name = stem[5:] if stem.startswith("best_") else stem  # e.g., best_resnet18 -> resnet18
        ckpt["model_name"] = model_name

    if num_classes is None:
        num_classes = ckpt.get("num_classes")
        if num_classes is None:
            raise ValueError("num_classes missing; pass num_classes=... to load_checkpoint")

    # --- 4) Build model and load weights
    model = create_model(model_name, num_classes=num_classes)

    state = ckpt.get("state_dict", ckpt)
    state = _strip_prefix(state, "model.")
    state = _strip_prefix(state, "net.")
    missing, unexpected = model.load_state_dict(state, strict=False)
    ckpt["load_warnings"] = {"missing": missing, "unexpected": unexpected}

    return model, ckpt
