#!/usr/bin/env python3
# (Rewriting after reset)
import argparse
import json
from pathlib import Path
from typing import List, Tuple, Optional

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def load_from_npz(path: Path) -> Tuple[np.ndarray, np.ndarray]:
    data = np.load(path, allow_pickle=False)
    probs = data["probs"]
    y_true = data["y_true"]
    if probs.ndim != 2:
        raise ValueError(f"'probs' must be 2D (N,C); got shape {probs.shape}")
    if y_true.ndim != 1:
        raise ValueError(f"'y_true' must be 1D (N,); got shape {y_true.shape}")
    if probs.shape[0] != y_true.shape[0]:
        raise ValueError("Mismatch: probs.shape[0] != y_true.shape[0]")
    row_sums = probs.sum(axis=1, keepdims=True)
    probs = probs / np.clip(row_sums, 1e-12, None)
    return probs.astype(np.float64), y_true.astype(np.int64)


def load_from_csv(path: Path, label_col: str, prob_prefix: Optional[str], prob_cols: Optional[List[str]]) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    df = pd.read_csv(path)
    if label_col not in df.columns:
        raise ValueError(f"Label column '{label_col}' not found in CSV")
    if prob_cols is None and prob_prefix is None:
        raise ValueError("Provide either --prob-prefix or --prob-cols for CSV input.")
    if prob_cols is None:
        prob_cols = sorted([c for c in df.columns if c.startswith(prob_prefix)])
        if not prob_cols:
            raise ValueError(f"No columns found with prefix '{prob_prefix}'")
    X = df[prob_cols].to_numpy(dtype=np.float64)
    y = df[label_col].to_numpy(dtype=np.int64)
    X_sum = X.sum(axis=1, keepdims=True)
    X = X / np.clip(X_sum, 1e-12, None)
    return X, y, prob_cols


def brier_score_multiclass(probs: np.ndarray, y_true: np.ndarray) -> float:
    n, c = probs.shape
    onehot = np.zeros((n, c), dtype=np.float64)
    onehot[np.arange(n), y_true] = 1.0
    return float(np.mean((probs - onehot) ** 2))


def ece_mce(probs: np.ndarray, y_true: np.ndarray, bins: int = 15, strategy: str = "uniform"):
    conf = probs.max(axis=1)
    pred = probs.argmax(axis=1)
    correct = (pred == y_true).astype(np.float64)
    n = probs.shape[0]

    if strategy == "uniform":
        edges = np.linspace(0.0, 1.0, bins + 1)
    elif strategy == "quantile":
        q = np.linspace(0.0, 1.0, bins + 1)
        edges = np.unique(np.quantile(conf, q))
        if edges.size < 2:
            edges = np.array([0.0, 1.0])
    else:
        raise ValueError("strategy must be one of {'uniform','quantile'}")

    bin_lowers = edges[:-1]
    bin_uppers = edges[1:]

    counts = []
    mean_conf = []
    mean_acc = []
    gaps = []

    ece = 0.0
    mce = 0.0

    for lower, upper in zip(bin_lowers, bin_uppers):
        in_bin = (conf >= lower) & (conf <= upper) if upper == 1.0 else (conf >= lower) & (conf < upper)
        bin_count = int(in_bin.sum())
        counts.append(bin_count)
        if bin_count > 0:
            bin_conf = float(conf[in_bin].mean())
            bin_acc = float(correct[in_bin].mean())
            gap = abs(bin_acc - bin_conf)
            mean_conf.append(bin_conf)
            mean_acc.append(bin_acc)
            gaps.append(gap)
            ece += (bin_count / n) * gap
            mce = max(mce, gap)
        else:
            mean_conf.append(np.nan)
            mean_acc.append(np.nan)
            gaps.append(np.nan)

    import pandas as pd
    bin_df = pd.DataFrame({
        "bin_lower": bin_lowers,
        "bin_upper": bin_uppers,
        "count": counts,
        "mean_confidence": mean_conf,
        "mean_accuracy": mean_acc,
        "gap": gaps,
    })
    return float(ece), float(mce), bin_df


def plot_reliability(bin_df: pd.DataFrame, out_png: Path, title: str = "Reliability Diagram"):
    fig = plt.figure(figsize=(6,6))
    ax = fig.add_subplot(111)
    x = bin_df["mean_confidence"].to_numpy()
    y = bin_df["mean_accuracy"].to_numpy()
    w = (bin_df["bin_upper"] - bin_df["bin_lower"]).to_numpy()
    mask = ~np.isnan(x) & ~np.isnan(y)
    ax.bar(x[mask], y[mask], width=w[mask]*0.95, align="center", edgecolor="black", linewidth=0.5, alpha=0.7)
    ax.plot([0,1],[0,1])
    ax.set_xlim(0,1); ax.set_ylim(0,1)
    ax.set_xlabel("Confidence")
    ax.set_ylabel("Accuracy")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_png, dpi=160)
    plt.close(fig)


def plot_confidence_accuracy_curve(probs: np.ndarray, y_true: np.ndarray, out_png: Path, title: str = "Confidence vs Accuracy"):
    conf = probs.max(axis=1)
    pred = probs.argmax(axis=1)
    correct = (pred == y_true).astype(np.float64)

    thresholds = np.linspace(0.0, 1.0, 101)
    accs = []
    coverages = []
    for t in thresholds:
        sel = conf >= t
        if sel.sum() == 0:
            accs.append(np.nan)
        else:
            accs.append(float(correct[sel].mean()))
        coverages.append(float(sel.mean()))

    fig = plt.figure(figsize=(7,5))
    ax = fig.add_subplot(111)
    ax.plot(thresholds, accs)
    ax.set_xlim(0,1); ax.set_ylim(0,1)
    ax.set_xlabel("Confidence threshold")
    ax.set_ylabel("Accuracy (on selected predictions)")
    ax.set_title(title)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_png, dpi=160)
    plt.close(fig)

    df = pd.DataFrame({"threshold": thresholds, "accuracy": accs, "coverage": coverages})
    return df


def parse_args():
    p = argparse.ArgumentParser(description="Calibration metrics for multiclass classification.")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--npz", type=str, help="NPZ with 'probs' (N,C) and 'y_true' (N,)")
    src.add_argument("--csv", type=str, help="CSV with one label col and class-probability columns")

    p.add_argument("--label-col", type=str, default="y_true", help="Label column name for CSV mode")
    p.add_argument("--prob-prefix", type=str, default=None, help="Prefix for prob columns in CSV (e.g., 'prob_')")
    p.add_argument("--prob-cols", type=str, default=None, help="Explicit prob columns (comma-separated)")

    p.add_argument("--bins", type=int, default=15, help="Number of bins for ECE/reliability diagram")
    p.add_argument("--binning", type=str, default="uniform", choices=["uniform", "quantile"], help="Binning strategy for ECE")
    p.add_argument("--outdir", type=str, default="calibration_reports", help="Output directory")
    return p.parse_args()


def main():
    args = parse_args()
    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)

    if args.npz:
        probs, y_true = load_from_npz(Path(args.npz))
        prob_colnames = [f"p{i}" for i in range(probs.shape[1])]
    else:
        prob_cols = None
        if args.prob_cols:
            prob_cols = [c.strip() for c in args.prob_cols.split(",") if c.strip()]
        probs, y_true, prob_colnames = load_from_csv(Path(args.csv), args.label_col, args.prob_prefix, prob_cols)

    brier = brier_score_multiclass(probs, y_true)
    ece, mce, bin_df = ece_mce(probs, y_true, bins=args.bins, strategy=args.binning)

    bin_csv = outdir / "calibration_bins.csv"
    bin_df.to_csv(bin_csv, index=False)

    rel_png = outdir / "reliability_diagram.png"
    plot_reliability(bin_df, rel_png)

    cav_png = outdir / "confidence_accuracy_curve.png"
    cav_df = plot_confidence_accuracy_curve(probs, y_true, cav_png)
    cav_df.to_csv(outdir / "confidence_accuracy_curve.csv", index=False)

    summary = {
        "brier_score": brier,
        "ECE": ece,
        "MCE": mce,
        "bins": args.bins,
        "binning": args.binning,
        "num_examples": int(probs.shape[0]),
        "num_classes": int(probs.shape[1]),
        "inputs": {
            "source": "npz" if args.npz else "csv",
            "path": args.npz if args.npz else args.csv,
            "label_col": None if args.npz else args.label_col,
            "prob_columns": None if args.npz else prob_colnames,
        }
    }
    with open(outdir / "calibration_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    print(f"Saved:\n - {bin_csv}\n - {rel_png}\n - {cav_png}\n - {outdir/'calibration_summary.json'}")


if __name__ == "__main__":
    main()
