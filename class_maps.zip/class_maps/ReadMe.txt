Use this when evaluating PlantVillage models against combined dataset for evaluation.

The combined dataset order and classes are correct

The plantvillage dataset classes are matched with the combined dataset order